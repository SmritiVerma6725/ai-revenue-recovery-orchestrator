[CmdletBinding()]
param(
    [string]$ArchivePath = (Join-Path $PSScriptRoot 'ai-revenue-recovery-pipeline.tar.gz'),
    [string]$InstallPath = (Join-Path $PSScriptRoot 'ai-revenue-recovery-demo'),
    [switch]$OpenWebsite
)

$ErrorActionPreference = 'Stop'
$dockerCommand = $null
$docker = Get-Command docker -ErrorAction SilentlyContinue

if (-not $docker) {
    $dockerPath = 'C:\Program Files\Docker\Docker\resources\bin\docker.exe'
    if (Test-Path $dockerPath) {
        $dockerCommand = $dockerPath
    } else {
        throw 'Docker was not found. Install and start Docker Desktop first.'
    }
} else {
    $dockerCommand = $docker.Source
}

if (-not (Test-Path $ArchivePath)) {
    throw "Tarball not found: $ArchivePath"
}

if (-not (Test-Path $InstallPath)) {
    New-Item -ItemType Directory -Path $InstallPath | Out-Null
}

Write-Host "Extracting $ArchivePath to $InstallPath..."
tar -xzf $ArchivePath -C $InstallPath

$envPath = Join-Path $InstallPath '.env'
$envExamplePath = Join-Path $InstallPath '.env.example'
if (-not (Test-Path $envPath)) {
    if (Test-Path $envExamplePath) {
        Copy-Item $envExamplePath $envPath
    } else {
        @(
            'RAZORPAY_KEY_ID=',
            'RAZORPAY_KEY_SECRET=',
            'WEBHOOK_SECRET=',
            'APP_ENV=development'
        ) | Set-Content $envPath
    }
}

Push-Location $InstallPath
try {
    Write-Host 'Starting the Docker demo...'
    & $dockerCommand compose up --build -d
    if ($LASTEXITCODE -ne 0) {
        throw 'Docker Compose failed to start the demo.'
    }

    $healthUrl = 'http://localhost:8000/health'
    $healthy = $false
    for ($attempt = 1; $attempt -le 12; $attempt++) {
        try {
            $response = Invoke-WebRequest $healthUrl -UseBasicParsing -TimeoutSec 5
            if ($response.StatusCode -eq 200) {
                $healthy = $true
                break
            }
        } catch {
            Start-Sleep -Seconds 2
        }
    }

    if (-not $healthy) {
        & $dockerCommand compose ps
        throw "The demo did not become healthy at $healthUrl"
    }

    Write-Host "Demo is running: http://localhost:8000"
    Write-Host "Health check passed: $($response.Content)"

    if (-not $OpenWebsite) {
        $answer = Read-Host 'Open the website now? (y/n)'
        $OpenWebsite = $answer -match '^(y|yes)$'
    }

    if ($OpenWebsite) {
        Start-Process 'http://localhost:8000'
    }
} finally {
    Pop-Location
}
