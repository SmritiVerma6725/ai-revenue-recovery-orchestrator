# AI Revenue Recovery Orchestrator

This repository is the starting point for the Razorpay AI Revenue Recovery challenge. The project models the end-to-end revenue recovery lifecycle: detect at-risk revenue, diagnose the issue, score recoverability, enforce guardrails, execute the best action, and track exactly how much money was recovered.

## Goals

- Model revenue at risk from failed payments and subscriptions
- Score recoverability using customer and transaction history
- Diagnose failure reasons with an AI-style reasoning layer
- Enforce business-safe guardrails before any action executes
- Surface recovered revenue as the primary KPI
- Provide a clear audit trail for explainability and compliance

## Repo structure

- `backend/` – FastAPI backend and orchestration logic
- `data/` – synthetic demo data for transactions and failures
- `tests/` – verification tests for API and logic flows
- `.env.example` – environment configuration template
- `Dockerfile` – container setup for deployment
- `docker-compose.yml` – local containerized run configuration
- `LINUX_SETUP.md` – exact Ubuntu/Linux extraction, startup, validation, and troubleshooting steps

## Local quick start

```bash
python -m venv .venv
. .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn backend.main:app --reload
```

Then open:

- http://localhost:8000/
- http://localhost:8000/health
- http://localhost:8000/api/dashboard
- http://localhost:8000/api/recovery-cases

## Environment configuration

Copy the template and populate values for deployment:

```bash
copy .env.example .env
```

Example values:

```env
APP_ENV=development
RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxxx
RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
WEBHOOK_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

## Docker run

```bash
docker build -t ai-revenue-recovery .
docker run -p 8000:8000 --env-file .env ai-revenue-recovery
```

Or with Docker Compose:

```bash
docker-compose up --build
```

## Demo baseline

The project uses realistic demo numbers aligned with the challenge narrative:

- Revenue at risk: ₹25,00,000
- Recoverable amount: ₹16,80,000
- Recovered amount: ₹8,73,450
- Recovery rate: 51.9%

## Notes

This project includes the core product flow, demo UI, auditability, persistence, and production-style configuration hooks. The remaining enhancements are optional extensions for live Razorpay production deployment and background automation.
