# Linux Setup and Demo Runbook

This guide runs the AI Revenue Recovery demo on Linux or Ubuntu/WSL with Docker.
The demo uses synthetic transactions and simulated recovery. It does not move real money.

## Prerequisites

Install or enable:

- Docker Engine and Docker Compose plugin, or Docker Desktop with WSL integration
- Bash
- `curl`
- `tar`
- Git, if cloning from GitHub

Check the tools:

```bash
docker --version
docker compose version
curl --version
tar --version
```

`docker version` must show both a Client and a Server section.

For Ubuntu/WSL with Docker Desktop, enable Ubuntu in:

```text
Docker Desktop -> Settings -> Resources -> WSL Integration -> Ubuntu -> Apply & Restart
```

If Docker reports permission denied on `/var/run/docker.sock`, run:

```bash
sudo usermod -aG docker "$USER"
```

Close and reopen Ubuntu, then run `docker version` again.

## Option 1: Clone the GitHub repository

```bash
git clone YOUR_GITHUB_REPOSITORY_URL.git
cd YOUR_REPOSITORY_DIRECTORY
```

Replace both placeholders with your real repository URL and directory name.

## Option 2: Extract the release tarball

If the tarball is on the Windows F: drive in WSL:

```bash
rm -rf ~/ai-revenue-recovery-demo
mkdir -p ~/ai-revenue-recovery-demo
ls -lh /mnt/f/Razorpay/ai-revenue-recovery-pipeline.tar.gz
tar -xzf /mnt/f/Razorpay/ai-revenue-recovery-pipeline.tar.gz \
  -C ~/ai-revenue-recovery-demo
cd ~/ai-revenue-recovery-demo
```

If the archive is in the current directory instead:

```bash
mkdir -p ~/ai-revenue-recovery-demo
tar -xzf ai-revenue-recovery-pipeline.tar.gz \
  -C ~/ai-revenue-recovery-demo
cd ~/ai-revenue-recovery-demo
```

Confirm the project files are present:

```bash
ls
```

Expected files include `Dockerfile`, `docker-compose.yml`, `backend`, `data`, and `tests`.

## Configure the demo

Create a local environment file. It is ignored by Git:

```bash
cp .env.example .env
```

For demo mode, keep the values blank:

```env
RAZORPAY_KEY_ID=
RAZORPAY_KEY_SECRET=
WEBHOOK_SECRET=
APP_ENV=development
```

Never commit `.env` or put real secrets in `.env.example`.

## Start the complete pipeline

```bash
docker version
docker compose version
docker compose config --quiet
docker compose down --remove-orphans 2>/dev/null || true
docker compose up --build -d
docker compose ps
```

The API container should show `Up` and port `8000` should be published.

## Wait for readiness

```bash
until curl -fsS http://localhost:8000/health; do
  sleep 2
done
echo
```

Expected response:

```json
{"status":"ok","service":"ai-revenue-recovery"}
```

## Verify every demo endpoint

```bash
curl -sS http://localhost:8000/health
echo
curl -sS http://localhost:8000/api/dashboard
echo
curl -sS http://localhost:8000/api/recovery-cases
echo
curl -sS http://localhost:8000/api/agent/decision
echo
curl -sS http://localhost:8000/api/audit-trail
echo
curl -sS http://localhost:8000/api/recovery-timeline
echo
```

## Show recovered revenue changing

The following changes only demo numbers. It does not call Razorpay or move money:

```bash
curl -sS -X POST http://localhost:8000/api/demo/simulate-recovery
echo
curl -sS http://localhost:8000/api/dashboard
echo
```

The recovered amount increases, revenue at risk decreases, and recovery rate is recalculated.

## Simulate a successful payment webhook

```bash
curl -sS -X POST http://localhost:8000/api/webhooks/razorpay \
  -H "Content-Type: application/json" \
  -d '{"event":"payment.captured","payload":{"payment":{"entity":{"id":"pay_demo_123","amount":14999,"currency":"INR"}}}}'
echo
```

Expected response contains `"status":"recovered"` and `"action":"stop"`.
This represents the stopping rule after payment success.

## Open the website

Ubuntu/WSL with a Windows browser:

```bash
explorer.exe http://localhost:8000
```

Native Ubuntu desktop:

```bash
xdg-open http://localhost:8000
```

For the video, show the KPI cards, the 30-day recovery graph, recovery cases, agent decision, audit trail, and the `Simulate recovered payment` button.

## Run tests inside the container

```bash
docker compose exec api pytest -q
```

Expected result is currently `36 passed`.

## Troubleshooting

### Docker command not found

Enable Docker Desktop WSL integration for Ubuntu, or install Docker Engine and the Compose plugin.

### Permission denied on Docker socket

```bash
sudo usermod -aG docker "$USER"
```

Close and reopen Ubuntu before retrying.

### Connection refused or reset on port 8000

The container may still be starting:

```bash
docker compose ps
docker logs ai-revenue-recovery
```

Restart and wait for readiness:

```bash
docker compose down --remove-orphans
docker compose up --build -d
until curl -fsS http://localhost:8000/health; do sleep 2; done
echo
```

### Duplicate container name

```bash
docker rm -f ai-revenue-recovery
docker compose up --build -d
```

### Archive not found

```bash
find /mnt/f -name 'ai-revenue-recovery-pipeline.tar.gz' 2>/dev/null
```

### Docker Desktop engine unavailable

Check:

```bash
wsl --status
docker version
```

Enable WSL2, Virtual Machine Platform, hardware virtualization, and Ubuntu WSL integration.

## Stop the demo

```bash
docker compose down
```
