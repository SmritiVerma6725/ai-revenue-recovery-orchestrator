# Demo Script

## 1. Opening hook (10-15 seconds)

"We built an AI Revenue Recovery Orchestrator for Razorpay merchants. Instead of blindly retrying failed payments, the system diagnoses the failure, scores recoverability, applies safety guardrails, and decides the best next action."

## 2. Show the dashboard (20-30 seconds)

Open the dashboard at http://localhost:8000/ and highlight:
- revenue at risk
- recoverable amount
- recovered amount
- recovery rate

"This is the executive view. We can instantly see how much revenue is at risk and how much is recoverable."

## 3. Show the case-level logic (20-30 seconds)

Open the recovery cases API or dashboard view and explain:
- customer profile
- payment amount
- failure reason
- score
- recommended action

"Each failed payment is scored based on customer behavior and transaction context. That means we do not treat every failure the same."

## 4. Explain the AI diagnosis and policy guardrails (20-30 seconds)

Describe the decision flow:
- identify likely failure reason
- estimate recovery probability
- check retry limits, amount thresholds, and message caps

"This is where the product becomes operationally safe. We do not retry forever or push risky actions. The policy layer is the control system."

## 5. Show the audit trail and timeline (20-30 seconds)

Show the audit trail and recovery timeline endpoints and explain:
- what happened
- why the action was chosen
- what changed after the customer responded

"Explainability is critical. Every action is traceable, which is important for support teams, finance teams, and compliance."

## 6. Close with business value (15-20 seconds)

"The outcome is simple: we convert failed payments into recovered revenue while preserving trust and staying within policy limits. This blends revenue intelligence with operational control."

## Short version for live presentation

"Our solution is an AI-powered revenue recovery orchestrator. It analyses failed payments, scores their recoverability, applies guardrails, and automatically chooses the best action — retry, payment link, reminder, or escalation. This turns lost payments into recovered revenue while maintaining trust and auditability."
